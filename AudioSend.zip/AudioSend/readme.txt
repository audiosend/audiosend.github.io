English:

1.Run the self-extracting AudioSend.sfx.part01, and the extracted file is the AudioSend.exe，It is a small green software that does not require installation.

2.if you use android audio device as wireless speaker, you need to run app(AndioReceiver.apk) in android device.

3.if you use bluetooth audio device as 5.1 wireless surround speaker, you only need to run program (AudioSend.exe) on computer.

Android: v4.0 above
(Can be installed on phone, smart speaker or tv box)

Computer OS: Windows 7/10/11

Wireless network: A good wireless network environment (at least 10Mbps bandwidth is guaranteed), and sound delays and stuttering may occur when the network is congested.

Get help, Blog :  audiosend.github.io

=================================================================

Chinese:

1.运行自解压缩AudioSend.sfx.part01，解压后的文件是AudioSend.exe，它是个小巧的绿色软件，不需要安装，直接运行即可。

2.如果你需要安卓音频设备(如手机或智能音箱等)作为电脑的无线音箱，需要在安卓音频设备上安装APP（AudioReceiver.apk）。

3.如果你只使用蓝牙音箱作为电脑的4/5.1多声道的后置无线音箱，则只需要在电脑(win7/win10/win11)上运行程序AudioSend.exe即可。

安卓要求: v4.0以上或更高
（可安装在手机，智能音箱或电视盒子）

电脑操作系统要求: Windows 7/10/11

无线网络要求: 良好的无线网络环境（至少保证10Mbps带宽富裕），网络拥塞时可能会出现声音的时延和卡顿。

网址：audiosend.github.io
