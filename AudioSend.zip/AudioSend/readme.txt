
1.if you use android audio device as wireless speaker, you need to run app (AndioRec.apk) in android device, and run program (AudioSend.exe) on computer.

2.if you use bluetooth audio device as wireless surround speaker, you only need to run program (AudioSend.exe) on computer.

Android: v4.0 above
(Can be installed on phone, smart speaker or tv box)

Computer OS: Windows 7/10/11


=======================================
AudioSend
将电脑上各声道（2/4/5.1/7.1）的音频数据流实时无损的发向不同安卓音频设备或蓝牙音频设备。

AudioRec
安卓音频设备实时接收并播放来自电脑的音频！

1.在安卓音频设备上安装APP（AudioRec.apk），在电脑(win7/win10/win11)上运行程序AudioSend.exe.

2.如果你只使用蓝牙音频设备，只需要在电脑(win7/win10/win11)上运行程序AudioSend.exe即可.

安卓要求: v4.0以上或更高
（可安装在手机，智能音箱或电视盒子）
电脑操作系统要求: Windows 7/10/11
