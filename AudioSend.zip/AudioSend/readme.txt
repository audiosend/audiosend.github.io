2023/2/11

1.if you use android audio device as wireless speaker, you need to run app(AndioRec.apk) in android device, and run setup program (AudioSend.msi) on computer.

2.if you use bluetooth audio device as wireless surround speaker, you only need to run setup program (AudioSend.msi) on computer.

Android: v4.0 above
(Can be installed on phone, smart speaker or tv box)

Computer OS: Windows 7/10/11

more detail:  https://audiosend.github.io/

=======================================

1.在安卓音频设备上安装APP（AudioRec.apk），在电脑(win7/win10/win11)上运行安装程序AudioSend.msi.

2.如果你只使用蓝牙音频设备，只需要在电脑(win7/win10/win11)上运行安装程序AudioSend.msi即可.

安卓要求: v4.0以上或更高
（可安装在手机，智能音箱或电视盒子）
电脑操作系统要求: Windows 7/10/11

更多信息： https://audiosend.github.io/
